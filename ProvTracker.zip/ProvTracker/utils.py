from vistrails.core.api import load_vistrail
import pprint
from dateutil.parser import *
import json
import os

pp = pprint.PrettyPrinter()


def diff(v1, v2):
    vt = load_vistrail('F:\\NOVOS\\VisTrails2\\examples\\PROVTRACKER_EX.vt')
    vt.select_latest_version()
    diffs = vt.controller.vistrail.get_pipeline_diff(v1, v2)

    print diffs

    pipe1 = diffs[0]
    pipe2 = diffs[1]
    on_both = diffs[2]
    on_v1 = diffs[4]
    on_v2 = diffs[5]
    diff_modules = diffs[6]

    DIFF = {}
    DIFF['ON_V1'] = [pipe1.get_module_by_id(id).name for id in on_v1]
    DIFF['ON_V2'] = [pipe2.get_module_by_id(id).name for id in on_v2]
    DIFF['MODULES'] = []

    for diff_module in diff_modules:
        DIFF_MODULE = {}

        mod1_id, mod2_id = diff_module[0]
        mod1 = pipe1.get_module_by_id(mod1_id)
        mod2 = pipe2.get_module_by_id(mod2_id)

        DIFF_MODULE['NAME'] = mod1.name
        DIFF_MODULE['DIFF_PARAMS'] = []

        for diff_param in diff_module[1]:
            DIFF_PARAMS = {}

            mod1_param = diff_param[0]
            mod2_param = diff_param[1]

            if mod1_param[0]:
                mod1_param_name = mod1_param[0]
                mod1_param_value = mod1_param[1][0][1]
            else:
                mod1_param_name = None
                mod1_param_value = None

            if mod2_param[0]:
                mod2_param_name = mod2_param[0]
                mod2_param_value = mod2_param[1][0][1]
            else:
                mod2_param_name = None
                mod2_param_value = None

            if not mod1_param_name and mod2_param_name:
                mod1_param_name = mod2_param_name
                mod1_param_value = 'Default'

            if not mod2_param_name and mod1_param_name:
                mod2_param_name = mod1_param_name
                mod2_param_value = 'Default'

            DIFF_PARAMS['ON_V1'] = (mod1_param_name, mod1_param_value)
            DIFF_PARAMS['ON_V2'] = (mod2_param_name, mod2_param_value)

            DIFF_MODULE['DIFF_PARAMS'].append(DIFF_PARAMS)

        DIFF['MODULES'].append(DIFF_MODULE)
    pp.pprint(DIFF)


    # DIFF['DIFFS'] = [pipe1.get_module_by_id(id).name for id in diff_params]


def look_for_execs(path):
    rel_path = os.path.join(os.path.dirname(__file__), 'examples', path)

    with open(rel_path + '.result.txt') as data_file:
        results = json.load(data_file)

    vt = load_vistrail(rel_path)
    vt.select_latest_version()
    PROJETO = vt.controller.name

    PIPELINE_EXECS = []
    PIPES = []
    for wf_exec in vt.controller.read_log().workflow_execs:
        PIPELINE_EXEC = {}
        PIPELINE_EXEC['ID'] = wf_exec.parent_version  # Mesmo valor do PIPE
        PIPELINE_EXEC['NOME'] = vt.controller.vistrail.getVersionName(wf_exec.parent_version)
        PIPELINE_EXEC['PROJETO'] = PROJETO
        PIPELINE_EXEC['PROV_ID'] = PIPELINE_EXEC['PROJETO'] + str(PIPELINE_EXEC['ID'])
        PIPELINE_EXEC['NOME_EXECUCAO'] = wf_exec.name
        PIPELINE_EXEC['USER'] = wf_exec.user
        PIPELINE_EXEC['VT_VERSION'] = wf_exec.vt_version
        PIPELINE_EXEC['TS_START'] = wf_exec.ts_start
        PIPELINE_EXEC['TS_END'] = wf_exec.ts_end
        PIPELINE_EXEC['COMPLETED'] = wf_exec.completed
        PIPELINE_EXEC['MODS_EXEC'] = []

        for result in results:
            res_start = parse(result['start'])
            if abs((res_start - wf_exec.ts_start).total_seconds()) < 5:
                PIPELINE_EXEC['RESULTS'] = result

        for mod_exec_obj in wf_exec.item_execs:
            MOD_EXEC = {}
            MOD_EXEC['ID'] = mod_exec_obj.module_id
            MOD_EXEC['NAME'] = mod_exec_obj.module_name
            MOD_EXEC['TS_START'] = mod_exec_obj.ts_start
            MOD_EXEC['TS_END'] = mod_exec_obj.ts_end
            MOD_EXEC['CACHED'] = mod_exec_obj.cached
            MOD_EXEC['COMPLETED'] = mod_exec_obj.completed
            MOD_EXEC['ERROR'] = mod_exec_obj.error

            PIPELINE_EXEC['MODS_EXEC'].append(MOD_EXEC)

        PIPELINE_EXECS.append(PIPELINE_EXEC)

        # NAO PRECISO CADASTRAR O PIPELINE DE NOVO, APENAS OS DADOS DA EXECUCAO
        if has_pipe_stored(PIPES, PIPELINE_EXEC['PROV_ID']):
            continue

        PIPE = {}
        PIPE['ID'] = wf_exec.parent_version  # Mesmo valor do PIPELINE_EXEC
        PIPE['PROJETO'] = PROJETO
        PIPE['PROV_ID'] = PIPE['PROJETO'] + str(PIPE['ID'])
        PIPE['NAME'] = vt.controller.vistrail.getVersionName(wf_exec.parent_version)
        PIPE['PIPE_NAME'] = vt.controller.vistrail.get_pipeline_name(wf_exec.parent_version)
        PIPE['LAST_MODIFIC'] = '??'
        PIPE['MODULES'] = []

        for mod_obj in vt.get_pipeline(wf_exec.parent_version).modules:
            MOD = {}
            MOD['ID'] = mod_obj.module.id
            MOD['PACKAGE'] = mod_obj.module.package
            MOD['NAME'] = mod_obj.module.name
            MOD['PARAMETERS'] = []

            for function_obj in mod_obj.module.functions:
                param_obj = function_obj.params[0]
                PARAM = {}
                PARAM['NAME'] = function_obj.name
                PARAM['TYPE'] = param_obj.typeStr.split(':')[-1]
                PARAM['VALUE'] = param_obj.strValue

                MOD['PARAMETERS'].append(PARAM)
                # print str(f.name), [(p.typeStr, p.name, p.strValue, p.value()) for p in f.params]
                # if len(function_obj.params) > 1:
                #    print 'HAHAHAHAHHAHAAHHAHHAAH'

            PIPE['MODULES'].append(MOD)
        PIPES.append(PIPE)

    return [PIPELINE_EXECS, PIPES]


def has_pipe_stored(pipes, id):
    for pipe in pipes:
        if pipe['PROV_ID'] == id:
            return True
    return False
