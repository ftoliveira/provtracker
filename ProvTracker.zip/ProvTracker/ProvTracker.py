import datetime

from flask import Flask
from flask.templating import render_template

import utils


DEBUG = True

app = Flask(__name__)
app.config.from_object(__name__)


@app.route('/')
def home():
    PIPELINE_EXECS, PIPES = utils.look_for_execs('RandomForestWorkflow.vt')
    PIPELINE_EXECS2, PIPES2 = utils.look_for_execs('SharedModelWorkflow.vt')
    PIPELINE_EXECS3, PIPES3 = utils.look_for_execs('Referee.vt')
    PIPELINE_EXECS4, PIPES4 = utils.look_for_execs('MergedScenariosWorkflow.vt')

    PIPES = PIPES + PIPES2 + PIPES3 + PIPES4
    PIPELINE_EXECS = PIPELINE_EXECS + PIPELINE_EXECS2 + PIPELINE_EXECS3 + PIPELINE_EXECS4

    resultados = []

    acuracia = {}
    for PIPE in PIPES:
        acuracias = []
        bot_precisions = []
        bot_recalls = []
        tempos = []
        PIPE['NUM_EXECS'] = 0
        for PIPELINE_EXEC in PIPELINE_EXECS:
            if PIPE['PROV_ID'] == PIPELINE_EXEC['PROV_ID']:
                PIPE['NUM_EXECS'] += 1
                tempo_exec_unitario = (PIPELINE_EXEC['TS_END'] - PIPELINE_EXEC['TS_START']).total_seconds()
                if tempo_exec_unitario > 10:
                    tempos.append(tempo_exec_unitario)

                for key, value in PIPELINE_EXEC['RESULTS'].iteritems():
                    if key == 'general':
                        acuracias.append(float(value['Accuracy']))
                    if key == 'bot':
                        bot_precisions.append(float(value['Precision']))
                        bot_recalls.append(float(value['Recall']))
        if acuracias:
            PIPE['ACURACIA_MEDIA'] = sum(acuracias) / float(len(acuracias))
        # else:
        #     acuracia[PIPE['ID']] = "-"
        if bot_precisions:
            PIPE['BOT_PREC_MEDIA'] = sum(bot_precisions) / float(len(bot_precisions))
        # else:
        #     bot_precisions[PIPE['ID']] = "-"
        if bot_recalls:
            PIPE['BOT_REC_MEDIA'] = sum(bot_recalls) / float(len(bot_recalls))

        if tempos:
            PIPE['TEMPO_MEDIO'] = datetime.timedelta(seconds=int(sum(tempos) / len(tempos))).__str__()
        else:
            PIPE['TEMPO_MEDIO'] = "-"

    return render_template('index.html', acuracia=acuracia, PIPES=PIPES, PIPELINE_EXECS=PIPELINE_EXECS)


@app.route('/workflow/<string:wf_id>')
def workflow(wf_id=None):
    PIPELINE_EXECS, PIPES = utils.look_for_execs('RandomForestWorkflow.vt')
    PIPELINE_EXECS2, PIPES2 = utils.look_for_execs('SharedModelWorkflow.vt')
    PIPELINE_EXECS3, PIPES3 = utils.look_for_execs('Referee.vt')
    PIPELINE_EXECS4, PIPES4 = utils.look_for_execs('MergedScenariosWorkflow.vt')
    PIPELINE_EXECS = PIPELINE_EXECS + PIPELINE_EXECS2 + PIPELINE_EXECS3 + PIPELINE_EXECS4

    EXECS = []
    for PIPELINE_EXEC in PIPELINE_EXECS:
        if PIPELINE_EXEC['PROV_ID'] == wf_id:
            EXECS.append(PIPELINE_EXEC)

    resultados = []

    return render_template('executions.html', resultados=resultados, PIPELINE_EXECS=EXECS)


if __name__ == '__main__':
    app.run()
